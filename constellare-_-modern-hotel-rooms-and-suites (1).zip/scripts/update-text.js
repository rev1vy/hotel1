const fs = require("fs");
const path = require("path");

const htmlPagesDir = path.join(__dirname, "..", "lib", "html-pages");
const files = fs.readdirSync(htmlPagesDir).filter(f => f.endsWith(".html"));

// Philosophy words
const philosophyWords = [
  "Located", "in", "Kalinganagar,", "Treebo", "Grace", "Stays,",
  "Sum", "Hospital", "offers", "comfortable", "rooms,",
  "essential", "amenities,", "complimentary", "breakfast",
  "and", "convenient", "access", "to", "Bhubaneswar."
];

// Interior video words
const interiorWords = [
  "Step", "inside", "Treebo", "Grace", "Stays,", "where",
  "comfortable", "rooms,", "convenient", "amenities", "and",
  "thoughtful", "hospitality", "come", "together", "in", "Bhubaneswar."
];

function transformHtml(content) {
  let res = content;

  // 1. Title and metadata
  res = res.replace(/<title>.*?<\/title>/gi, '<title>Treebo Grace Stays, SUM Hospital, Bhubaneswar</title>');
  res = res.replace(/content="Constellare \| Modern Hotel Rooms and Suites"/g, 'content="Treebo Grace Stays, SUM Hospital, Bhubaneswar"');
  res = res.replace(/content="Book a stay at Constellare[^"]*"/g, 'content="Book a stay at Treebo Grace Stays in Kalinganagar, Bhubaneswar, near SUM Hospital. Comfortable rooms, complimentary breakfast, on-site dining and 24-hour reception."');

  // 2. Navigation & Logo
  res = res.replace(/>Constellare<\/h5>/g, '>Treebo Grace Stays</h5>');
  res = res.replace(/>Articles<\/p>/g, '>Explore</p>');
  res = res.replace(/>Events<\/p>/g, '>Explore</p>');
  res = res.replace(/>About us<\/p>/g, '>About Us</p>');
  res = res.replace(/>For Parent<\/p>/g, '>Our Rooms</p>');
  res = res.replace(/>Book your stay<\/p>/g, '>Book Your Stay</p>');

  // 3. Hero section
  res = res.replace(
    /Constellare, every stay is shaped by thoughtful design, intuitive service, and an effortless journey from your first enquiry to checkout\./g,
    'A comfortable stay in Kalinganagar, Bhubaneswar, close to SUM Hospital and convenient for exploring the city.'
  );
  // Main Hero H1 (in SVG / fit-text)
  res = res.replace(/>Constellare<\/h1>/g, '>Treebo Grace Stays</h1>');

  // Hero rating badge
  res = res.replace(/>4\.9<\/h2>/g, '>★</h2>');
  res = res.replace(/>Excellent<\/p>/g, '>Verified Stay</p>');

  // 4. Philosophy section
  res = res.replace(/>Our Philosophy<\/h2>/g, '>A Comfortable Stay, Thoughtfully Managed</h2>');
  res = res.replace(/>See more about us<\/p>/g, '>Explore The Hotel</p>');

  // Replace Philosophy reveal spans in all 3 breakpoints
  res = res.replace(/<h4 style="max-width:100%;width:100%;text-align:center"><span style="color:var\(--token-c3472735-fdaa-4517-81a2-b86c52088285[^>]*>We<!-- --> <\/span>[\s\S]*?<\/h4>/g, (match) => {
    // extract style from first span
    const styleMatch = match.match(/<span style="([^"]*)">/);
    const spanStyle = styleMatch ? styleMatch[1] : '';
    const spans = philosophyWords.map((w, idx) => {
      const isLast = idx === philosophyWords.length - 1;
      return `<span style="${spanStyle}">${w}${isLast ? '' : '<!-- --> '}</span>`;
    }).join('');
    return `<h4 style="max-width:100%;width:100%;text-align:center">${spans}</h4>`;
  });

  // 5. Why Stay With Us
  res = res.replace(
    /Every stay at Constellare is shaped by calm design, considered service, and a booking experience that stays effortless from first enquiry to checkout\./g,
    'Every stay at Treebo Grace Stays is shaped by comfort, considered service, and a booking experience that stays effortless from first enquiry to checkout.'
  );
  // Card 1
  res = res.replace(/>Effortless Booking<\/h4>/g, '>Convenient Location</h4>');
  res = res.replace(
    /Check real availability, compare rooms, and confirm your stay in minutes, with clear rates, flexible dates, and no hidden charges\./g,
    'Located in Kalinganagar with easy access to SUM Hospital and nearby destinations.'
  );
  // Card 2
  res = res.replace(/>Restful Rooms<\/h4>/g, '>Comfortable Rooms</h4>');
  res = res.replace(
    /Every room is prepared for genuine rest, with premium linens, quiet interiors, considered lighting, and city views that make evenings feel\./g,
    'Standard and Deluxe rooms with the essentials for a relaxed stay.'
  );
  // Card 3
  res = res.replace(/>Personal Service<\/h4>/g, '>Complimentary Breakfast</h4>');
  res = res.replace(
    /Our team remembers preferences, arranges special requests, and stays available around the clock so support is never away\./g,
    'Enjoy complimentary breakfast during your stay.'
  );
  // Card 4
  res = res.replace(/>Central Location<\/h4>/g, '>On-Site Dining</h4>');
  res = res.replace(
    /Stay minutes from the city’s dining, culture, and business districts, with concierge guidance and transfers arranged whenever you need them\./g,
    'Kegs And Barrel serves Indian and Chinese cuisine.'
  );

  // 6. How We Host
  res = res.replace(
    /The art of a memorable stay lives in the details: clear booking, considered rooms, and a team that anticipates what you need next\./g,
    'Everything you need for a comfortable and convenient stay in Bhubaneswar.'
  );
  // Tab items & descriptions
  res = res.replace(/>Attentive Hosts<\/h4>/g, '>Comfortable Rooms</h4>');
  res = res.replace(
    /Our front desk and concierge teams are trained in genuine hospitality, ready to handle late arrivals, dining reservations, and any request during your stay\./g,
    'Settle into a well-equipped room designed for a comfortable stay.'
  );

  res = res.replace(/>Rooms Prepared For You<\/h4>/g, '>Essential Amenities</h4>');
  res = res.replace(
    /Tell us your preferences at booking \(bedding, floor level, quiet side, celebrations\) and we will have the room arranged before you arrive\./g,
    'Enjoy air conditioning, Wi-Fi, TV, workspace and everyday essentials.'
  );

  res = res.replace(/>Comfort and Security<\/h4>/g, '>Dining On Site</h4>');
  res = res.replace(
    /Secure key access, 24-hour reception, and carefully maintained rooms mean you can settle in, rest deeply, and explore the city with confidence\./g,
    'Enjoy Indian and Chinese cuisine at Kegs And Barrel.'
  );

  res = res.replace(/>Flexible Stays<\/h4>/g, '>Convenient Location</h4>');
  res = res.replace(
    /Extend a night, adjust arrival times, or shift dates where availability allows\. Our booking terms are written to stay clear and reasonable\./g,
    'Stay close to SUM Hospital and well connected to key parts of Bhubaneswar.'
  );

  res = res.replace(/>From Booking To Checkout<\/h4>/g, '>Easy Check-In</h4>');
  res = res.replace(
    /A single, seamless experience: transparent rates, quick confirmation, smooth check-in, and a relaxed departure with billing handled properly\./g,
    'A straightforward stay with a 24-hour front desk for guest assistance.'
  );

  // 7. Rooms Section
  res = res.replace(
    /Eight thoughtfully designed rooms and suites, each ready to book with flexible stays and personalised service\./g,
    'Comfortable accommodation for every kind of stay in Bhubaneswar.'
  );
  res = res.replace(/>Vega Suite<\/h3>/g, '>Standard Room</h3>');
  res = res.replace(/>Altair Room<\/h3>/g, '>Deluxe Room</h3>');
  res = res.replace(/>Antares Suite<\/h3>/g, '>Standard Room</h3>');
  res = res.replace(/>Capella King<\/h3>/g, '>Deluxe Room</h3>');

  // Replace prices: $189, $129, $235, $155 with "View", and "PER NIGHT" with "ROOM"
  res = res.replace(/>\$(?:189|129|235|155)<\/p>/g, '>View</p>');
  res = res.replace(/>PER <\/p><p[^>]*>NIGHT<\/p>/g, '>BOOK <\/p><p dir="auto" class="framer-text">STAY</p>');

  // 8. Large Mid-Page Interior Video Experience
  res = res.replace(/<span style="display:inline-block;opacity:0\.001;filter:blur\(4px\);transform:translateX\(0px\) translateY\(10px\) scale\(1\) rotate\(0deg\) skewX\(0deg\) skewY\(0deg\)">Step<\/span>[\s\S]*?meet<\/span>/g, () => {
    return interiorWords.map(w => {
      return `<span style="display:inline-block;opacity:0.001;filter:blur(4px);transform:translateX(0px) translateY(10px) scale(1) rotate(0deg) skewX(0deg) skewY(0deg)">${w}</span>`;
    }).join(' ');
  });

  // 9. Testimonials
  res = res.replace(/>Testimonials<\/h2>/g, '>Guest Experiences</h2>');
  res = res.replace(
    /Hear from guests who have stayed with us, on how easy the booking felt and how restful the rooms turned out to be\./g,
    'Hear from guests who have stayed with Treebo Grace Stays and experienced the comfort of our rooms, convenient location and hospitality.'
  );
  res = res.replace(/>Booking took two minutes<\/h3>/g, '>Comfortable &amp; Convenient</h3>');
  res = res.replace(
    /I compared rooms, chose the corner suite, and had confirmation instantly\. Check-in was just as smooth and the room matched the photos exactly\./g,
    'Comfortable rooms and a convenient location make this a practical base for a stay in Bhubaneswar.'
  );
  res = res.replace(/>Jessica Turner<\/p>/g, '>Verified Guest</p>');

  // 10. Articles section -> Explore Bhubaneswar
  res = res.replace(/>Articles<\/h2>/g, '>Explore Bhubaneswar</h2>');
  res = res.replace(
    /Hear from guests who have stayed with us, on how easy the booking felt and how restful the rooms turned out to be\./g,
    'Discover places worth exploring during your stay in Bhubaneswar.'
  );
  res = res.replace(/>See all articles<\/p>/g, '>Explore The City</p>');
  res = res.replace(
    />How to Choose the Room That Fits the Trip You Are Actually Taking<\/h5>/g,
    '>Udayagiri &amp; Khandagiri Caves</h5><p class="framer-text" style="font-size:14px;opacity:0.8;margin-top:6px">Explore one of Bhubaneswar\'s best-known historic attractions.</p>'
  );
  res = res.replace(
    />What Booking Direct Gets You That an Aggregator Cannot<\/h5>/g,
    '>ISKCON Bhubaneswar</h5><p class="framer-text" style="font-size:14px;opacity:0.8;margin-top:6px">Visit one of the city\'s prominent temples and cultural landmarks.</p>'
  );
  res = res.replace(
    />Arriving Well: The First Hour of a Stay Sets the Rest<\/h5>/g,
    '>Jayadev Vatika</h5><p class="framer-text" style="font-size:14px;opacity:0.8;margin-top:6px">A nearby green space for a quieter break from the city.</p>'
  );

  // 11. FAQ Section
  res = res.replace(
    /Everything you need to know about booking, arriving, and settling in at Constellare\. If your question isn’t answered here, our front desk is always a message away\./g,
    'Everything you need to know before your stay.'
  );
  // Q1
  res = res.replace(
    />What are your check-in and check-out times\?<\/p>/g,
    '>What time is check-in and check-out?</p>'
  );
  res = res.replace(
    />Check-in opens at 3:00 PM and check-out is at 11:00 AM\. Early arrival and late departure can usually be arranged\. Mention it when you book and we will hold the room wherever availability allows\./g,
    '>Check-in is from 1:00 PM and check-out is until 11:00 AM.'
  );
  // Q2
  res = res.replace(
    />Can I change or cancel a booking after it is confirmed\?<\/p>/g,
    '>Does the hotel offer Wi-Fi?</p>'
  );
  res = res.replace(
    />Yes\. Flexible rates can be changed or cancelled free of charge up to 48 hours before arrival\. Saver rates are non-refundable, and the exact conditions are always shown before you confirm\./g,
    '>Yes. Complimentary Wi-Fi is available.'
  );
  // Q3
  res = res.replace(
    />How do I choose the right room or suite\?<\/p>/g,
    '>Does the hotel provide breakfast?</p>'
  );
  res = res.replace(
    />Our eight rooms and suites range from compact doubles for short city stays to garden suites built for longer visits\. Every listing shows the bed configuration, view, and maximum occupancy, and our team is happy to recommend one\./g,
    '>Yes. Complimentary breakfast is available.'
  );
  // Q4
  res = res.replace(
    />Is breakfast included, and what else can I use during my stay\?<\/p>/g,
    '>Does the hotel have a restaurant?</p>'
  );
  res = res.replace(
    />Breakfast is included with all direct bookings[^<]*<\/p>/g,
    '>Yes. Kegs And Barrel is the hotel\'s in-house restaurant serving Indian and Chinese cuisine.</p>'
  );

  // 12. Follow / Social
  res = res.replace(/>Follow @Constellare<\/h2>/g, '>Discover Treebo Grace Stays</h2>');
  res = res.replace(
    />Take a look at life at Constellare[^<]*<\/p>/g,
    '>Take a closer look at the rooms, interiors and spaces that make your stay comfortable.</p>'
  );

  // 13. Footer
  res = res.replace(/>Open 24 hours, every day of the year<\/p>/g, '>Open 24 hours for guest assistance</p>');
  res = res.replace(/>Check-in from 3:00 PM · Check-out by 11:00 AM<\/p>/g, '>Check-in from 1:00 PM · Check-out by 11:00 AM</p>');
  res = res.replace(
    /12 Lantern Street, New York, NY 10013/g,
    'Plot No. 2601, 1st Floor, Khata No. 2365/635, Bharatpur, Kalinganagar, Bhubaneswar, Odisha 751029'
  );
  // Remove phone and email tags if present
  res = res.replace(/<div class="framer-3fnjwh"[\s\S]*?<\/div><div class="framer-mhv21z"[\s\S]*?<\/div>/g, '<div class="framer-3fnjwh"><p class="framer-text" style="color:rgba(255,255,255,0.65)">Kalinganagar, Bhubaneswar, Odisha</p></div>');
  res = res.replace(/© 2026 Constellare\. All rights reserved\./g, '© 2026 Treebo Grace Stays. All rights reserved.');
  res = res.replace(/>Constellare<\/p><\/foreignObject><\/svg>/g, '>TREEBO GRACE STAYS</p></foreignObject></svg>');

  // Also replace any remaining "Constellare" with "Treebo Grace Stays" in visible text nodes
  res = res.replace(/>Constellare</g, '>Treebo Grace Stays<');

  return res;
}

// Client synchronization script to ensure text stays updated if React re-hydrates or updates
const clientSyncScript = `
<script id="treebo-text-sync">
(function() {
  const replacements = [
    [/Constellare/gi, "Treebo Grace Stays"],
    [/New York, NY 10013/gi, "Kalinganagar, Bhubaneswar, Odisha 751029"],
    [/12 Lantern Street/gi, "Plot No. 2601, Bharatpur, Kalinganagar"],
    [/\\+1 212 555 0148/gi, "SUM Hospital Road, Kalinganagar"],
    [/stay@constellare\\.com/gi, "Bhubaneswar, Odisha"],
    [/Our Philosophy/g, "A Comfortable Stay, Thoughtfully Managed"],
    [/See more about us/gi, "Explore The Hotel"],
    [/Effortless Booking/g, "Convenient Location"],
    [/Restful Rooms/g, "Comfortable Rooms"],
    [/Personal Service/g, "Complimentary Breakfast"],
    [/Central Location/g, "On-Site Dining"],
    [/Attentive Hosts/g, "Comfortable Rooms"],
    [/Rooms Prepared For You/g, "Essential Amenities"],
    [/Comfort and Security/g, "Dining On Site"],
    [/Flexible Stays/g, "Convenient Location"],
    [/From Booking To Checkout/g, "Easy Check-In"],
    [/Check real availability, compare rooms[^<]*/gi, "Located in Kalinganagar with easy access to SUM Hospital and nearby destinations."],
    [/Every room is prepared for genuine rest[^<]*/gi, "Standard and Deluxe rooms with the essentials for a relaxed stay."],
    [/Our team remembers preferences[^<]*/gi, "Enjoy complimentary breakfast during your stay."],
    [/Stay minutes from the city’s dining[^<]*/gi, "Kegs And Barrel serves Indian and Chinese cuisine."],
    [/Our front desk and concierge teams are trained in genuine hospitality[^<]*/gi, "Settle into a well-equipped room designed for a comfortable stay."],
    [/Tell us your preferences at booking[^<]*/gi, "Enjoy air conditioning, Wi-Fi, TV, workspace and everyday essentials."],
    [/Secure key access, 24-hour reception[^<]*/gi, "Enjoy Indian and Chinese cuisine at Kegs And Barrel."],
    [/Extend a night, adjust arrival times[^<]*/gi, "Stay close to SUM Hospital and well connected to key parts of Bhubaneswar."],
    [/A single, seamless experience: transparent rates[^<]*/gi, "A straightforward stay with a 24-hour front desk for guest assistance."],
    [/Vega Suite/g, "Standard Room"],
    [/Altair Room/g, "Deluxe Room"],
    [/Antares Suite/g, "Standard Room"],
    [/Capella King/g, "Deluxe Room"],
    [/\\$(?:189|129|235|155)/g, "View"],
    [/PER\\s*NIGHT/gi, "BOOK STAY"],
    [/Jessica Turner/g, "Verified Guest"],
    [/Booking took two minutes/g, "Comfortable & Convenient"],
    [/I compared rooms, chose the corner suite[^<]*/gi, "Comfortable rooms and a convenient location make this a practical base for a stay in Bhubaneswar."],
    [/Hear from guests who have stayed with us, on how easy the booking felt[^<]*/gi, "Hear from guests who have stayed with Treebo Grace Stays and experienced the comfort of our rooms, convenient location and hospitality."],
    [/How to Choose the Room That Fits the Trip You Are Actually Taking/gi, "Udayagiri & Khandagiri Caves"],
    [/What Booking Direct Gets You That an Aggregator Cannot/gi, "ISKCON Bhubaneswar"],
    [/Arriving Well: The First Hour of a Stay Sets the Rest/gi, "Jayadev Vatika"],
    [/See all articles/gi, "Explore The City"],
    [/What are your check-in and check-out times\\?/gi, "What time is check-in and check-out?"],
    [/Check-in opens at 3:00 PM and check-out is at 11:00 AM[^<]*/gi, "Check-in is from 1:00 PM and check-out is until 11:00 AM."],
    [/Can I change or cancel a booking after it is confirmed\\?/gi, "Does the hotel offer Wi-Fi?"],
    [/Yes\\. Flexible rates can be changed or cancelled free of charge[^<]*/gi, "Yes. Complimentary Wi-Fi is available."],
    [/How do I choose the right room or suite\\?/gi, "Does the hotel provide breakfast?"],
    [/Our eight rooms and suites range from compact doubles[^<]*/gi, "Yes. Complimentary breakfast is available."],
    [/Is breakfast included, and what else can I use during my stay\\?/gi, "Does the hotel have a restaurant?"],
    [/Breakfast is included with all direct bookings[^<]*/gi, "Yes. Kegs And Barrel is the hotel's in-house restaurant serving Indian and Chinese cuisine."],
    [/Follow @Constellare/gi, "Discover Treebo Grace Stays"],
    [/Take a look at life at Constellare[^<]*/gi, "Take a closer look at the rooms, interiors and spaces that make your stay comfortable."],
    [/Open 24 hours, every day of the year/gi, "Open 24 hours for guest assistance"],
    [/Check-in from 3:00 PM · Check-out by 11:00 AM/gi, "Check-in from 1:00 PM · Check-out by 11:00 AM"]
  ];

  function replaceInNode(node) {
    if (node.nodeType === 3) {
      let val = node.nodeValue;
      let changed = false;
      for (const [pattern, repl] of replacements) {
        if (pattern.test(val)) {
          val = val.replace(pattern, repl);
          changed = true;
        }
      }
      if (changed) node.nodeValue = val;
    } else if (node.nodeType === 1 && node.childNodes) {
      if (node.tagName === 'SCRIPT' || node.tagName === 'STYLE') return;
      for (let i = 0; i < node.childNodes.length; i++) {
        replaceInNode(node.childNodes[i]);
      }
    }
  }

  // Initial replacement
  replaceInNode(document.body);

  // Observe future mutations (e.g. React hydration or tab switching)
  const observer = new MutationObserver(mutations => {
    for (const m of mutations) {
      if (m.type === 'characterData') {
        replaceInNode(m.target);
      } else if (m.type === 'childList') {
        m.addedNodes.forEach(n => replaceInNode(n));
      }
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true
  });
})();
</script>
`;

// Process all HTML files
for (const file of files) {
  const filePath = path.join(htmlPagesDir, file);
  let content = fs.readFileSync(filePath, "utf8");
  content = transformHtml(content);

  if (!content.includes('id="treebo-text-sync"')) {
    content = content.replace("</body>", clientSyncScript + "\n</body>");
  }

  fs.writeFileSync(filePath, content, "utf8");
  console.log(`Processed: ${file}`);
}
console.log("All HTML files updated successfully!");
