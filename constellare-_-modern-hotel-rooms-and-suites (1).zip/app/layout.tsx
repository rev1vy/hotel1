import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Treebo Grace Stays, SUM Hospital, Bhubaneswar',
  description:
    'Book a stay at Treebo Grace Stays in Kalinganagar, Bhubaneswar, near SUM Hospital. Comfortable rooms, complimentary breakfast, on-site dining and 24-hour reception.',
  openGraph: {
    title: 'Treebo Grace Stays, SUM Hospital, Bhubaneswar',
    description:
      'Book a stay at Treebo Grace Stays in Kalinganagar, Bhubaneswar, near SUM Hospital. Comfortable rooms, complimentary breakfast, on-site dining and 24-hour reception.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Treebo Grace Stays, SUM Hospital, Bhubaneswar',
    description:
      'Book a stay at Treebo Grace Stays in Kalinganagar, Bhubaneswar, near SUM Hospital. Comfortable rooms, complimentary breakfast, on-site dining and 24-hour reception.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
