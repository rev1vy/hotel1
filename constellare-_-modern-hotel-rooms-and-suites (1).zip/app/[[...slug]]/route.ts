import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";

export const dynamic = "force-dynamic";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug?: string[] }> }
) {
  const { slug } = await params;
  const pathname = new URL(request.url).pathname;

  const htmlDir = path.join(process.cwd(), "lib", "html-pages");

  let targetFile = "index.html";

  if (!slug || slug.length === 0 || pathname === "/") {
    targetFile = "index.html";
  } else {
    const slugPath = slug.join("/");
    const normalizedName = slug.join("_") + ".html";

    if (fs.existsSync(path.join(htmlDir, normalizedName))) {
      targetFile = normalizedName;
    } else if (slug[0] === "rooms" && slug.length > 1) {
      targetFile = `rooms_${slug[1]}.html`;
    } else if (slug[0] === "articles" && slug.length > 1) {
      targetFile = `articles_${slug[1]}.html`;
    } else if (fs.existsSync(path.join(htmlDir, `${slug[0]}.html`))) {
      targetFile = `${slug[0]}.html`;
    } else {
      targetFile = "index.html";
    }
  }

  const filePath = path.join(htmlDir, targetFile);

  if (!fs.existsSync(filePath)) {
    const fallbackPath = path.join(htmlDir, "index.html");
    const fallbackHtml = fs.readFileSync(fallbackPath, "utf8");
    return new NextResponse(fallbackHtml, {
      headers: {
        "content-type": "text/html; charset=utf-8",
      },
    });
  }

  let html = fs.readFileSync(filePath, "utf8");

  // Inject <base href="/" /> if not present to ensure relative navigation works from subroutes
  if (!html.includes("<base ")) {
    html = html.replace("<head>", '<head>\n\t<base href="/">');
  }

  return new NextResponse(html, {
    headers: {
      "content-type": "text/html; charset=utf-8",
      "cache-control": "no-store, must-revalidate",
    },
  });
}
